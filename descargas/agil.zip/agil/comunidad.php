<?php 
	$titulo = 'Comunidad'; // Título
	$contenido = '<h1>Participar en la Comunidad Agilista</h1>

<div id="multimedia"><img src="imagenes/comunidad.jpg"  class="jsnipLightBox thumbImg" alt="contactos de comunidades agilistas"/></div>

	<p>Una de las formas más eficientes de realizar consultas, hacer propuestas, aclarar dudas y crear es participando en las listas de correo de las comunidades agilistas. Te recomendamos que te suscribas y participes en las siguientes:</p><br \>


	<p><span class="menu">6</span><a href="http://agilescolombia.org/" target="_blank">Agiles Colombia</a>: <a href="https://groups.google.com/forum/?fromgroups#!forum/agiles-colombia" target="_blank">Lista de correo</a> <span class="social"><a href="https://www.facebook.com/AgilesColombia" target="_blank" class="fb2">f</a><a href="https://groups.google.com/forum/?fromgroups#!forum/agiles-colombia" target="_blank" class="g2">g</a><a href="https://twitter.com/agilescolombia" target="_blank" class="tw2">u</a><a href="#" target="_blank" class="in2">i</a></span></p>
	<p><span class="menu">6</span>LocXue: <a href="https://groups.google.com/forum/?hl=es&fromgroups=#!forum/locxue" target="_blank">Lista de correo</a> <span class="social"><a href="https://www.facebook.com/locxue" target="_blank" class="fb2">f</a><a href="https://groups.google.com/forum/?hl=es&fromgroups=#!forum/locxue" target="_blank" class="g2">g</a><a href="https://twitter.com/locxue" target="_blank" class="tw2">u</a><a href="#" target="_blank" class="in2">i</a></span></p>



	'; // Contenido
	require('base/general.php');
?>

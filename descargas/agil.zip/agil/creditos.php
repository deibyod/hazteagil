<?php 
	$titulo = 'Cr&eacute;ditos y Licencia'; // Título
	$contenido = '
	<div style="float:right; text-align:right;"><p style="float:right; text-align:right;"><img src="imagenes/udec.png" align="right" width="130px">
	Universidad de Cundinamarca<br \>
	Fusagasug&aacute;, Cundinamarca.<br \>
	Ingenier&iacute;a de Sistemas.<br \>
	Colombia. <br \>
	Versión 1.0<br \>
	Noviembre, 2012.
	</p></div>
	
	<div style="clear:both; float: right;">
	<h1>Licencia:</h1>
	<p><a href="licencia/Creative Commons — Reconocimiento 3.0 Unported — CC BY 3.0.html" target="_blank" style="border:0;">
	<img src="imagenes/copyleft.png"><br \>
	<img src="imagenes/chooser_by.png">	<img src="imagenes/chooser_cc.png"><br \>
	</a></p>
	</div>
	
	<h1>Realizado por:</h1>
	<p><i>LocXu&eacute;, Software Enginering</i><br \>Cristian Camilo Velasquez Ardila<br \>
	Deiby Fabi&aacute;n Ordo&ntilde;ez D&iacute;az
	</p>
	
	<h1>Destinado a:</h1>
	<p>Semillero de Investigaci&oacute;n en Ingenier&iacute;a de Software LocXu&eacute;.<br \>
	Comunidad Agilista.</p>
	
	<h1>Proyecto de:</h1>
	<p>Electiva Profesional<br \>
	Ing. Esperanza Merchan</p>
	
	<div>
	<h1>Descargar:</h1>	
	<span class="botones"><a href="descargas/agil.zip"><span style="font-family:unicons;">V</span>MDM</a></span>	<span class="botones"><a href="descargas/informe.pdf"><span style="font-family:unicons;">V</span>documentación</a></span>
	</div>
	'; // Contenido
	require('base/general.php');
?>

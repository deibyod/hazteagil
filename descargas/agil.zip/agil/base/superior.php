<body onload="new Accordian('basic-accordian',5,'header_highlight');">
	<div id="contenedor">
		<div id="superior"> <!-- Cabecera -->
			<span class="social"><a id="fb" href="https://www.facebook.com/locxue" target="_blank">f</a><a id="g" href="https://groups.google.com/forum/?hl=es&fromgroups=#!forum/locxue" target="_blank">g</a><a id="tw" href="https://twitter.com/locxue" target="_blank">u</a><a id="in">i</a></span><span id="titulo1">Hazte &Aacute;gil y Hazlo Simple</span>
			<span id="titulo2">&#124; <?php echo $titulo; ?></span>
			<span class="menu" style="float: right;"><a id="info" href="info.php">,</a><a id="creditos" href="creditos.php">*</a><a id="cerrar" href="javascript:alert('Para salir por favor cierre manualmente la ventana. Los navegadores modernos impiden el cierre a través de código ya que es una acción intrusiva, es decir, es una medida de seguridad.')">|</a></span>
		</div>

<?php
	require('head.php');
	require('scripts.php');
	require('superior.php');
	require('medio.php');
	require('inferior.php');
?>

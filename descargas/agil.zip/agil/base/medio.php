		<div id="medio"> <!-- Contenido -->
			<div id="contenido"><p><?php echo $contenido; ?></p></div>
		</div> 

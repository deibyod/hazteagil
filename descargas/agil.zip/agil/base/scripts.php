	<!-- Lightbox y otros recursos -->
	<link rel='stylesheet' href='js/jsnip.css' type='text/css' />
	<script type="text/javascript" src='js/base.min.js'></script> 
	<script type="text/javascript" src='js/jsnip.min.js'></script> 
	<!-- Fin Lightbox y otros recursos -->

	<!-- Slide -->
	<link rel="stylesheet" type="text/css" href="slide/estilosSlide.css" />
	<script type="text/javascript" src="slide/jquery.js"></script>
	<script type="text/javascript" src="slide/fadeSlideShow.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function(){
		jQuery('#slideshow').fadeSlideShow();
		});
	</script>
	<!-- Fin Slide -->

	<!-- Accordion -->
	<script type="text/javascript" src="accordion/accordian.pack.js"></script>
	<!-- Fin Accordion -->

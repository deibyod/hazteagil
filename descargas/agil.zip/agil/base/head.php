<!DOCTYPE HTML>
<html>
<head>
	<title>Hazte &Aacute;gil y Hazlo Simple - <?php echo $titulo ?></title> <!-- Titulo -->
	<link rel="stylesheet" type="text/css" href="base/estilos.css" /> <!-- Estilos -->
	<meta name="description" content="MDM Metodologías ágiles de desarrollo de software">
	<meta name="keywords" content="agil, agile, software, metodologias, scrum, kiss" />
	<meta name="author" content="Deiby Ordoñez - Camilo Velasquez">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<?php 
	require('navegacion.php');
	$contenido = '<p>Selecciona la evaluación de tu preferencia.</p>

<span class="botones"><a href="1.evaluacion.php"><span style="font-family:socialbats;">[</span> Tomar Evaluación de Etapa 1</a></span>
<span class="botones"><a href="2.evaluacion.php"><span style="font-family:socialbats;">[</span> Tomar Evaluación de Etapa 2</a></span>
<span class="botones"><a href="3.evaluacion.php"><span style="font-family:socialbats;">[</span> Tomar Evaluación de Etapa 3</a></span>
	
	'; // Contenido
	require('base/general.php');
?>
